var app=angular.module('Myapp',[]);
app.controller('myCtrl',function($scope,$http){
	//document format if square brakects are represented as array
	$scope.student={}
	$scope.studentdata=[]
	$scope.loginform=function(val){
		$http({
			method:'post',
			url:'/checkdata',
			data:val
		}).then(function(success){
			console.log(success)
			if(success.data==''){
				alert("some Credentials wrong")
			}else{
					location.href="/courses"
					alert("login success")
					
			}
		},function(err){
			console.log(err);
			alert("incorrect data")
		})
		//this method used for checking the data while enter into courses if data of user present in our database or not.
	}
	$scope.upd={}
	$scope.upddata=[]
	$scope.registration=function(val){
		$http({
			method:'post',
			url:'/senddata',
			data: val
		}).then(function(success){
			console.log(success);
			alert("successfully submitted");
			location.href="/login"
			},function(err){
				console.log(err);
			})
		//this method used in registration form to register as a new user
	}
	$scope.admin={}
	$scope.admindata=[]
	$scope.adminform=function(val){
		$http({
			method:'post',
			url:'/adminpost',
			data: val
		}).then(function(success){
			console.log(success);
			alert("successfully submitted");
			location.href="/adminlogin"
			},function(err){
				console.log(err);
			})
		//this method used in registration form to register as a new user
	}
	$scope.adminlog={}
	$scope.adminlogdata=[]
	$scope.adminlogin=function(val){
		$http({
			method:'post',
			url:'/adminlogin',
			data:val
		}).then(function(success){
			console.log(success)
			if(success.data==''){
				alert("some Credentials wrong")
			}else{
					location.href="/admindata"
					alert("login success")
					
			}
		},function(err){
			console.log(err);
			alert("incorrect data")
		})
		//this method used for checking the data while enter into courses if data of user present in our database or not.
	}
	
	$scope.get1=function(){
		$http({
			method:'get',
			url:'/getdata',
		}).then(function(success){
			console.log(success);
			$scope.upddata=success.data
		},function(err){
			console.log(err);
		})
	}
	$scope.Update=function(val){
		$http({
			method:'post',
			url:'/post1',
			data:val
		}).then(function(sucess){
			console.log(success);
		},function(err){
			console.log(err);
		})
	}
});
