var mongoose=require('mongoose');
var CheckSchema=mongoose.Schema;
var InsertSchema=new CheckSchema({
	firstname:String,
	lastname:String,
	//address:String,
	//Branch:String
})
//collection name is "Insert"
module.exports=mongoose.model('Inserts',InsertSchema);